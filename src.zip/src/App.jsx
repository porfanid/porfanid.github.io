import React, { useState, useEffect } from 'react';
import anime from 'animejs/lib/anime.es.js';
import { useScrollAnimation } from './hooks/useScrollAnimation';
import Header from './components/Header';
import Tabs from './components/Tabs';
import Projects from './components/Projects';
import Books from './components/Books';
import Footer from './components/Footer';

// Το API endpoint της NASA (με thumbs για βίντεο)
const NASA_APOD_ENDPOINT = `https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&thumbs=true`;

function App() {
  const [activeTab, setActiveTab] = useState('projects');
  const [backgroundImage, setBackgroundImage] = useState('');
  const [apodTitle, setApodTitle] = useState('');

  const heroRef = useScrollAnimation({
    translateY: [24, 0],
    opacity: [0, 1],
    duration: 900,
    easing: 'easeOutExpo',
  });

  useEffect(() => {
    // Φέρνουμε την εικόνα της ημέρας όταν φορτώνει η εφαρμογή
    fetch(NASA_APOD_ENDPOINT)
      .then(res => res.json())
      .then(data => {
        setApodTitle(data.title || 'Astronomy Picture of the Day');
        // Ελέγχουμε αν το APOD είναι εικόνα (μερικές φορές είναι βίντεο)
        if (data.media_type === 'image') {
          setBackgroundImage(data.hdurl || data.url);
        } else if (data.media_type === 'video' && data.thumbnail_url) {
          setBackgroundImage(data.thumbnail_url);
        } else if (data.url) {
          setBackgroundImage(data.url);
        } else {
          setBackgroundImage('https://api.nasa.gov/assets/img/general/apod.jpg');
        }
      })
      .catch(error => {
        console.error("Could not fetch NASA APOD:", error);
        // Βάζουμε μια default εικόνα σε περίπτωση σφάλματος
        setBackgroundImage('https://api.nasa.gov/assets/img/general/apod.jpg');
        setApodTitle('Astronomy Picture of the Day');
      });
  }, []); // Το [] σημαίνει ότι θα τρέξει μόνο μία φορά στην αρχή

  return (
    // Χρησιμοποιούμε τη νέα κλάση και περνάμε τη διεύθυνση της εικόνας στη CSS μεταβλητή
    <div 
      className="app-container" 
      style={{ '--bg-image': `url(${backgroundImage})` }}
    >

      <Header username="porfanid" />

      <nav className="main-tabs-nav">
        <Tabs
          tabs={[
            { id: 'projects', label: 'Projects' },
            { id: 'books', label: 'Books' },
          ]}
          activeTab={activeTab}
          onChange={setActiveTab}
        />
      </nav>

      <main>
        {activeTab === 'projects' && (
          <section className="projects">
            <div className="container">
              {/* Αφαίρεσα τον τίτλο από εδώ για να μην επαναλαμβάνεται */}
              <Projects />
            </div>
          </section>
        )}

        {activeTab === 'books' && (
          <section className="books-section">
            <div className="container">
              <h2 className="section-title">My Books</h2>
              <Books />
            </div>
          </section>
        )}
      </main>

      <Footer username="porfanid" />
    </div>
  );
}

export default App;
